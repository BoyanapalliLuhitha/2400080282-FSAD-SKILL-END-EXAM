# Shipment Management Service

A Spring Boot REST API for managing shipments using Spring Data JPA and H2 in-memory database.

## Tech Stack

- Java 17
- Spring Boot 3.2
- Spring Data JPA
- H2 Database (in-memory)
- Bean Validation
- Lombok
- Maven

## Project Structure

```
src/
└── main/
    ├── java/com/example/shipment/
    │   ├── ShipmentApplication.java       # Main entry point
    │   ├── controller/
    │   │   └── ShipmentController.java    # REST endpoints
    │   ├── service/
    │   │   └── ShipmentService.java       # Business logic
    │   ├── repository/
    │   │   └── ShipmentRepository.java    # JPA repository
    │   ├── entity/
    │   │   └── Shipment.java              # JPA entity (auto ID)
    │   ├── enums/
    │   │   └── ShipmentStatus.java        # Status enum
    │   ├── dto/
    │   │   ├── ShipmentRequest.java       # Input DTO
    │   │   └── ShipmentResponse.java      # Output DTO
    │   └── exception/
    │       ├── ResourceNotFoundException.java
    │       └── GlobalExceptionHandler.java
    └── resources/
        ├── application.properties
        └── data.sql                       # Sample data
```

## API Endpoints

| Method | Endpoint                        | Description              |
|--------|---------------------------------|--------------------------|
| POST   | `/api/shipments`                | Create a new shipment    |
| PUT    | `/api/shipments/{id}`           | Update an existing shipment |
| GET    | `/api/shipments`                | Get all shipments        |
| GET    | `/api/shipments/{id}`           | Get shipment by ID       |
| GET    | `/api/shipments/status/{status}`| Filter by status         |
| DELETE | `/api/shipments/{id}`           | Delete a shipment        |

## Shipment Status Values

```
PENDING | PROCESSING | SHIPPED | IN_TRANSIT | OUT_FOR_DELIVERY | DELIVERED | CANCELLED | RETURNED
```

## How to Run

### Prerequisites
- Java 17+
- Maven 3.6+

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/your-username/shipment-service.git
cd shipment-service

# 2. Build the project
mvn clean install

# 3. Run the application
mvn spring-boot:run
```

The app starts at: `http://localhost:8080`

H2 Console (DB browser): `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:shipmentdb`
- Username: `sa`
- Password: *(leave blank)*

## Sample API Requests

### Create Shipment (POST)

```bash
curl -X POST http://localhost:8080/api/shipments \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Electronics Package",
    "status": "PENDING",
    "trackingNumber": "TRK-100",
    "senderName": "Alice Kumar",
    "senderAddress": "12 MG Road, Hyderabad",
    "receiverName": "Bob Sharma",
    "receiverAddress": "45 Park Street, Mumbai",
    "receiverEmail": "bob@example.com",
    "receiverPhone": "+91-9876543210",
    "weightKg": 2.5,
    "declaredValue": 15000.00,
    "shippingCost": 350.00,
    "carrier": "BlueDart"
  }'
```

### Update Shipment (PUT)

```bash
curl -X PUT http://localhost:8080/api/shipments/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Electronics Package",
    "status": "IN_TRANSIT",
    "trackingNumber": "TRK-100",
    "senderName": "Alice Kumar",
    "senderAddress": "12 MG Road, Hyderabad",
    "receiverName": "Bob Sharma",
    "receiverAddress": "45 Park Street, Mumbai",
    "carrier": "BlueDart"
  }'
```

### Get All Shipments (GET)

```bash
curl http://localhost:8080/api/shipments
```

### Get by Status (GET)

```bash
curl http://localhost:8080/api/shipments/status/PENDING
```

## Entity Fields

| Field            | Type           | Description                        |
|------------------|----------------|------------------------------------|
| id               | Long           | Auto-generated primary key         |
| name             | String         | Shipment label/name                |
| status           | ShipmentStatus | Enum status value                  |
| trackingNumber   | String         | Unique tracking number             |
| senderName       | String         | Sender's full name                 |
| senderAddress    | String         | Sender's address                   |
| receiverName     | String         | Receiver's full name               |
| receiverAddress  | String         | Receiver's address                 |
| receiverEmail    | String         | Receiver's email                   |
| receiverPhone    | String         | Receiver's phone                   |
| weightKg         | Double         | Package weight in kg               |
| declaredValue    | BigDecimal     | Declared monetary value            |
| shippingCost     | BigDecimal     | Cost of shipping                   |
| carrier          | String         | Shipping carrier (FedEx, DHL etc.) |
| estimatedDelivery| LocalDateTime  | Expected delivery date/time        |
| actualDelivery   | LocalDateTime  | Actual delivery date/time          |
| notes            | String         | Additional notes                   |
| createdAt        | LocalDateTime  | Auto-set on creation               |
| updatedAt        | LocalDateTime  | Auto-updated on change             |

## License

MIT License
