-- Sample data loaded on startup (H2 compatible)
INSERT INTO shipments (name, status, tracking_number, sender_name, sender_address, receiver_name, receiver_address, receiver_email, receiver_phone, weight_kg, declared_value, shipping_cost, carrier, notes)
VALUES
('Electronics Package', 'PENDING', 'TRK-001', 'Alice Kumar', '12 MG Road, Hyderabad', 'Bob Sharma', '45 Park Street, Mumbai', 'bob@example.com', '+91-9876543210', 2.5, 15000.00, 350.00, 'BlueDart', 'Handle with care'),
('Clothing Bundle', 'SHIPPED', 'TRK-002', 'Priya Reddy', '88 Banjara Hills, Hyderabad', 'Ravi Patel', '22 FC Road, Pune', 'ravi@example.com', '+91-9123456789', 1.2, 3000.00, 120.00, 'DTDC', NULL),
('Books Collection', 'DELIVERED', 'TRK-003', 'Suresh Nair', '5 Anna Salai, Chennai', 'Meena Iyer', '10 Rajaji Nagar, Bengaluru', 'meena@example.com', '+91-9988776655', 3.8, 800.00, 200.00, 'India Post', 'Educational books');
