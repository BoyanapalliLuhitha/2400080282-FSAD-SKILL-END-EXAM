package com.example.shipment.repository;

import com.example.shipment.entity.Shipment;
import com.example.shipment.enums.ShipmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShipmentRepository extends JpaRepository<Shipment, Long> {

    Optional<Shipment> findByTrackingNumber(String trackingNumber);

    List<Shipment> findByStatus(ShipmentStatus status);

    List<Shipment> findByReceiverEmail(String receiverEmail);

    List<Shipment> findBySenderName(String senderName);

    boolean existsByTrackingNumber(String trackingNumber);
}
