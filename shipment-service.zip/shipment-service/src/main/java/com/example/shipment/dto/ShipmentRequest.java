package com.example.shipment.dto;

import com.example.shipment.enums.ShipmentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ShipmentRequest {

    @NotBlank(message = "Shipment name is required")
    private String name;

    @NotNull(message = "Status is required")
    private ShipmentStatus status;

    private String trackingNumber;

    @NotBlank(message = "Sender name is required")
    private String senderName;

    @NotBlank(message = "Sender address is required")
    private String senderAddress;

    @NotBlank(message = "Receiver name is required")
    private String receiverName;

    @NotBlank(message = "Receiver address is required")
    private String receiverAddress;

    private String receiverEmail;

    private String receiverPhone;

    private Double weightKg;

    private BigDecimal declaredValue;

    private BigDecimal shippingCost;

    private String carrier;

    private LocalDateTime estimatedDelivery;

    private LocalDateTime actualDelivery;

    private String notes;
}
