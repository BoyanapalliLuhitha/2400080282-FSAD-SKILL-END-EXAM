package com.example.shipment.service;

import com.example.shipment.dto.ShipmentRequest;
import com.example.shipment.dto.ShipmentResponse;
import com.example.shipment.entity.Shipment;
import com.example.shipment.enums.ShipmentStatus;
import com.example.shipment.exception.ResourceNotFoundException;
import com.example.shipment.repository.ShipmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;

    // POST - Create a new shipment
    public ShipmentResponse createShipment(ShipmentRequest request) {
        Shipment shipment = Shipment.builder()
                .name(request.getName())
                .status(request.getStatus())
                .trackingNumber(request.getTrackingNumber())
                .senderName(request.getSenderName())
                .senderAddress(request.getSenderAddress())
                .receiverName(request.getReceiverName())
                .receiverAddress(request.getReceiverAddress())
                .receiverEmail(request.getReceiverEmail())
                .receiverPhone(request.getReceiverPhone())
                .weightKg(request.getWeightKg())
                .declaredValue(request.getDeclaredValue())
                .shippingCost(request.getShippingCost())
                .carrier(request.getCarrier())
                .estimatedDelivery(request.getEstimatedDelivery())
                .actualDelivery(request.getActualDelivery())
                .notes(request.getNotes())
                .build();

        Shipment saved = shipmentRepository.save(shipment);
        return mapToResponse(saved);
    }

    // PUT - Full update of an existing shipment
    public ShipmentResponse updateShipment(Long id, ShipmentRequest request) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment", id));

        shipment.setName(request.getName());
        shipment.setStatus(request.getStatus());
        shipment.setTrackingNumber(request.getTrackingNumber());
        shipment.setSenderName(request.getSenderName());
        shipment.setSenderAddress(request.getSenderAddress());
        shipment.setReceiverName(request.getReceiverName());
        shipment.setReceiverAddress(request.getReceiverAddress());
        shipment.setReceiverEmail(request.getReceiverEmail());
        shipment.setReceiverPhone(request.getReceiverPhone());
        shipment.setWeightKg(request.getWeightKg());
        shipment.setDeclaredValue(request.getDeclaredValue());
        shipment.setShippingCost(request.getShippingCost());
        shipment.setCarrier(request.getCarrier());
        shipment.setEstimatedDelivery(request.getEstimatedDelivery());
        shipment.setActualDelivery(request.getActualDelivery());
        shipment.setNotes(request.getNotes());

        Shipment updated = shipmentRepository.save(shipment);
        return mapToResponse(updated);
    }

    // GET - All shipments
    public List<ShipmentResponse> getAllShipments() {
        return shipmentRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // GET - Single shipment by ID
    public ShipmentResponse getShipmentById(Long id) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment", id));
        return mapToResponse(shipment);
    }

    // GET - Shipments by status
    public List<ShipmentResponse> getShipmentsByStatus(ShipmentStatus status) {
        return shipmentRepository.findByStatus(status)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // DELETE - Remove shipment
    public void deleteShipment(Long id) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment", id));
        shipmentRepository.delete(shipment);
    }

    // Mapper: Entity → Response DTO
    private ShipmentResponse mapToResponse(Shipment shipment) {
        ShipmentResponse response = new ShipmentResponse();
        response.setId(shipment.getId());
        response.setName(shipment.getName());
        response.setStatus(shipment.getStatus());
        response.setTrackingNumber(shipment.getTrackingNumber());
        response.setSenderName(shipment.getSenderName());
        response.setSenderAddress(shipment.getSenderAddress());
        response.setReceiverName(shipment.getReceiverName());
        response.setReceiverAddress(shipment.getReceiverAddress());
        response.setReceiverEmail(shipment.getReceiverEmail());
        response.setReceiverPhone(shipment.getReceiverPhone());
        response.setWeightKg(shipment.getWeightKg());
        response.setDeclaredValue(shipment.getDeclaredValue());
        response.setShippingCost(shipment.getShippingCost());
        response.setCarrier(shipment.getCarrier());
        response.setEstimatedDelivery(shipment.getEstimatedDelivery());
        response.setActualDelivery(shipment.getActualDelivery());
        response.setNotes(shipment.getNotes());
        response.setCreatedAt(shipment.getCreatedAt());
        response.setUpdatedAt(shipment.getUpdatedAt());
        return response;
    }
}
