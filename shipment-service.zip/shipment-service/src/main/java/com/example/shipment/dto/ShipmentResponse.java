package com.example.shipment.dto;

import com.example.shipment.enums.ShipmentStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ShipmentResponse {

    private Long id;
    private String name;
    private ShipmentStatus status;
    private String trackingNumber;
    private String senderName;
    private String senderAddress;
    private String receiverName;
    private String receiverAddress;
    private String receiverEmail;
    private String receiverPhone;
    private Double weightKg;
    private BigDecimal declaredValue;
    private BigDecimal shippingCost;
    private String carrier;
    private LocalDateTime estimatedDelivery;
    private LocalDateTime actualDelivery;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
